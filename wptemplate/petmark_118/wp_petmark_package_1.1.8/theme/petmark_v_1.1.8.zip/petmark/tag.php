<?php
/**
 * The template for displaying Tag pages
 *
 * Used to display archive-type pages for posts in a tag.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Petmark_Theme
 * @since Petmark 1.0
 */

$petmark_opt = get_option( 'petmark_opt' );

get_header();

$petmark_bloglayout = 'sidebar';
if(isset($petmark_opt['blog_layout']) && $petmark_opt['blog_layout']!=''){
	$petmark_bloglayout = $petmark_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$petmark_bloglayout = $_GET['layout'];
}
$petmark_blogsidebar = 'right';
if(isset($petmark_opt['sidebarblog_pos']) && $petmark_opt['sidebarblog_pos']!=''){
	$petmark_blogsidebar = $petmark_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$petmark_blogsidebar = $_GET['sidebar'];
}
if ( !is_active_sidebar( 'sidebar-1' ) )  {
	$petmark_bloglayout = 'nosidebar';
}
switch($petmark_bloglayout) {
	case 'sidebar':
		$petmark_blogclass = 'blog-sidebar';
		$petmark_blogcolclass = 9;
		Petmark_Class::petmark_post_thumbnail_size('petmark-category-thumb');
		break;
	case 'largeimage':
		$petmark_blogclass = 'blog-large';
		$petmark_blogcolclass = 9;
		$petmark_postthumb = '';
		break;
	default:
		$petmark_blogclass = 'blog-nosidebar';
		$petmark_blogcolclass = 12;
		$petmark_blogsidebar = 'none';
		Petmark_Class::petmark_post_thumbnail_size('petmark-post-thumb');
}
?>
<div class="main-container page-wrapper">
	<div class="breadcrumbs-wrapper">
		<div class="container">
			<div class="breadcrumbs-inner">
				<?php Petmark_Class::petmark_breadcrumb(); ?> 
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			
			<?php if($petmark_blogsidebar=='left') : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>
			
			<div class="col-xs-12 <?php echo 'col-md-'.$petmark_blogcolclass; ?>">
			
				<div class="page-content blog-page <?php echo esc_attr($petmark_blogclass); if($petmark_blogsidebar=='left') {echo ' left-sidebar'; } if($petmark_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
					<?php if ( have_posts() ) : ?>
						<header class="archive-header">
							<h1 class="archive-title"><?php printf( wp_kses(__( 'Tag Archives: %s', 'petmark' ), array('span'=>array())), '<span>' . single_tag_title( '', false ) . '</span>' ); ?></h1>

						<?php if ( tag_description() ) : // Show an optional tag description ?>
							<div class="archive-meta"><?php echo tag_description(); ?></div>
						<?php endif; ?>
						</header><!-- .archive-header -->

						<?php
						/* Start the Loop */
						while ( have_posts() ) : the_post();

							/*
							 * Include the post format-specific template for the content. If you want to
							 * this in a child theme then include a file called called content-___.php
							 * (where ___ is the post format) and that will be used instead.
							 */
							get_template_part( 'content', get_post_format() );

						endwhile;
						?>
						
						<?php Petmark_Class::petmark_pagination(); ?>
						
					<?php else : ?>
						<?php get_template_part( 'content', 'none' ); ?>
					<?php endif; ?>
				</div>
			</div>

			<?php if( $petmark_blogsidebar=='right') : ?>
				<?php get_sidebar(); ?>
			<?php endif; ?>
			
		</div>
		
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($petmark_opt['inner_brand']) && function_exists('petmark_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($petmark_opt['inner_brand'] && isset($petmark_opt['brand_logos'][0]) && $petmark_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($petmark_opt['inner_brand_title']) && $petmark_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $petmark_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>
<?php get_footer(); ?>
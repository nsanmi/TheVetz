		var petmark_brandnumber = 6,
			petmark_brandscrollnumber = 2,
			petmark_brandpause = 3000,
			petmark_brandanimate = 2000;
		var petmark_brandscroll = false;
							petmark_brandscroll = true;
					var petmark_categoriesnumber = 6,
			petmark_categoriesscrollnumber = 2,
			petmark_categoriespause = 3000,
			petmark_categoriesanimate = 700;
		var petmark_categoriesscroll = 'false';
					var petmark_blogpause = 3000,
			petmark_bloganimate = 2000;
		var petmark_blogscroll = false;
							petmark_blogscroll = false;
					var petmark_testipause = 3000,
			petmark_testianimate = 2000;
		var petmark_testiscroll = false;
							petmark_testiscroll = false;
					var petmark_catenumber = 6,
			petmark_catescrollnumber = 2,
			petmark_catepause = 3000,
			petmark_cateanimate = 700;
		var petmark_catescroll = false;
					var petmark_menu_number = 9;
		var petmark_sticky_header = false;
							petmark_sticky_header = true;
					jQuery(document).ready(function(){
			jQuery("#ws").on('focus', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#ws").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#wsearchsubmit").on('click', function(){
				if(jQuery("#ws").val()=="" || jQuery("#ws").val()==""){
					jQuery("#ws").focus();
					return false;
				}
			});
			jQuery("#search_input").on('focus', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#search_input").on('focusout', function(){
				if(jQuery(this).val()==""){
					jQuery(this).val("");
				}
			});
			jQuery("#blogsearchsubmit").on('click', function(){
				if(jQuery("#search_input").val()=="" || jQuery("#search_input").val()==""){
					jQuery("#search_input").focus();
					return false;
				}
			});
		});
		
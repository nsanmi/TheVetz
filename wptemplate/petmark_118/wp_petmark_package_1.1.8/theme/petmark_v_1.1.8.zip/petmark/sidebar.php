<?php
/**
 * The sidebar containing the main widget area
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Petmark_Theme
 * @since Petmark 1.0
 */

$petmark_opt = get_option( 'petmark_opt' );
 
$petmark_blogsidebar = 'right';
if(isset($petmark_opt['sidebarblog_pos']) && $petmark_opt['sidebarblog_pos']!=''){
	$petmark_blogsidebar = $petmark_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$petmark_blogsidebar = $_GET['sidebar'];
}
?>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="secondary" class="col-xs-12 col-md-3">
		<div class="sidebar-border <?php echo esc_attr($petmark_blogsidebar);?>">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div><!-- #secondary -->
<?php endif; ?>
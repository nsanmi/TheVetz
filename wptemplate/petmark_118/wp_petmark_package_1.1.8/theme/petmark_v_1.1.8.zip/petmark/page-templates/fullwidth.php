<?php
/**
 * Template Name: Full Width
 *
 * Description: Full Width page template
 *
 * @package WordPress
 * @subpackage Petmark_Theme
 * @since Petmark 1.0
 */
$petmark_opt = get_option( 'petmark_opt' );

get_header();
?>
<div class="main-container full-width">
	<div class="title-breadcrumbs <?php if(isset($petmark_opt['page_banner']['url']) && ($petmark_opt['page_banner']['url'])!=''){ echo 'has-page-banner'; } ?>">
		<?php if(isset($petmark_opt['page_banner']['url']) && ($petmark_opt['page_banner']['url'])!=''){ ?>
			<div class="page-banner">
				<img src="<?php echo esc_url($petmark_opt['page_banner']['url']); ?>" alt="<?php echo esc_attr('Page banner','petmark') ?>" />
			</div>
		<?php } ?>
		<div class="title-breadcrumbs-inner">
			<div class="container">
				<header class="entry-header">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header>
				<?php Petmark_Class::petmark_breadcrumb(); ?> 
			</div>
		</div>
	</div>
	<div class="page-content">
		<div class="container">
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', 'page' ); ?>
			<?php endwhile; ?>
		</div> 
	</div>
</div>
<?php get_footer(); ?>
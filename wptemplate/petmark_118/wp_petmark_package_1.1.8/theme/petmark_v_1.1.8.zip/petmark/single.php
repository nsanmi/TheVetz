<?php
/**
 * The Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Petmark_Theme
 * @since Petmark 1.0
 */

$petmark_opt = get_option( 'petmark_opt' );

get_header();

$petmark_bloglayout = 'sidebar';
if(isset($petmark_opt['blog_layout']) && $petmark_opt['blog_layout']!=''){
	$petmark_bloglayout = $petmark_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$petmark_bloglayout = $_GET['layout'];
}
$petmark_blogsidebar = 'right';
if(isset($petmark_opt['sidebarblog_pos']) && $petmark_opt['sidebarblog_pos']!=''){
	$petmark_blogsidebar = $petmark_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$petmark_blogsidebar = $_GET['sidebar'];
}
if ( !is_active_sidebar( 'sidebar-1' ) )  {
	$petmark_bloglayout = 'nosidebar';
}
switch($petmark_bloglayout) {
	case 'sidebar':
		$petmark_blogclass = 'blog-sidebar';
		$petmark_blogcolclass = 9;
		break;
	default:
		$petmark_blogclass = 'blog-nosidebar'; //for both fullwidth and no sidebar
		$petmark_blogcolclass = 12;
		$petmark_blogsidebar = 'none';
}
?>
<div class="main-container page-wrapper">
	<div class="page-content">
		<div class="breadcrumbs-wrapper">
			<div class="container">
				<div class="breadcrumbs-inner">
					<?php Petmark_Class::petmark_breadcrumb(); ?> 
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">

				<?php
				$customsidebar = get_post_meta( $post->ID, '_petmark_custom_sidebar', true );
				$customsidebar_pos = get_post_meta( $post->ID, '_petmark_custom_sidebar_pos', true );

				if($customsidebar != ''){
					if($customsidebar_pos == 'left' && is_active_sidebar( $customsidebar ) ) {
						echo '<div id="secondary" class="col-xs-12 col-md-3">';
							dynamic_sidebar( $customsidebar );
						echo '</div>';
					} 
				} else {
					if($petmark_blogsidebar=='left') {
						get_sidebar();
					}
				} ?>

				<div class="col-xs-12 <?php echo 'col-md-'.$petmark_blogcolclass; ?>">
					<div class="page-content blog-page single <?php echo esc_attr($petmark_blogclass); if($petmark_blogsidebar=='left') {echo ' left-sidebar'; } if($petmark_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
						<?php while ( have_posts() ) : the_post(); ?>

							<?php get_template_part( 'content', get_post_format() ); ?>

							<?php comments_template( '', true ); ?>
							
							<!--<nav class="nav-single">
								<h3 class="assistive-text"><?php esc_html_e( 'Post navigation', 'petmark' ); ?></h3>
								<span class="nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'petmark' ) . '</span> %title' ); ?></span>
								<span class="nav-next"><?php next_post_link( '%link', '%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'petmark' ) . '</span>' ); ?></span>
							</nav><!-- .nav-single -->
							
						<?php endwhile; // end of the loop. ?>
					</div>
				</div>
				
				<?php
				if($customsidebar != ''){
					if($customsidebar_pos == 'right' && is_active_sidebar( $customsidebar ) ) {
						echo '<div id="secondary" class="col-xs-12 col-md-3">';
							dynamic_sidebar( $customsidebar );
						echo '</div>';
					} 
				} else {
					if($petmark_blogsidebar=='right') {
						get_sidebar();
					}
				} ?>
				
			</div>
		</div> 
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($petmark_opt['inner_brand']) && function_exists('petmark_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($petmark_opt['inner_brand'] && isset($petmark_opt['brand_logos'][0]) && $petmark_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($petmark_opt['inner_brand_title']) && $petmark_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $petmark_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>

<?php get_footer(); ?>
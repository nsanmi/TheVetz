<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * For example, it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Petmark_Theme
 * @since Petmark 1.0
 */

$petmark_opt = get_option( 'petmark_opt' );

get_header();

$petmark_bloglayout = 'sidebar';

if(isset($petmark_opt['blog_layout']) && $petmark_opt['blog_layout']!=''){
	$petmark_bloglayout = $petmark_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$petmark_bloglayout = $_GET['layout'];
}
$petmark_blogsidebar = 'right';
if(isset($petmark_opt['sidebarblog_pos']) && $petmark_opt['sidebarblog_pos']!=''){
	$petmark_blogsidebar = $petmark_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$petmark_blogsidebar = $_GET['sidebar'];
}
if ( !is_active_sidebar( 'sidebar-1' ) )  {
	$petmark_bloglayout = 'nosidebar';
}
switch($petmark_bloglayout) {
	case 'sidebar':
		$petmark_blogclass = 'blog-sidebar';
		$petmark_blogcolclass = 9;
		Petmark_Class::petmark_post_thumbnail_size('petmark-post-thumb');
		break;
	case 'largeimage':
		$petmark_blogclass = 'blog-large';
		$petmark_blogcolclass = 9;
		Petmark_Class::petmark_post_thumbnail_size('petmark-category-thumb');
		break;
	case 'grid':
		$petmark_blogclass = 'grid';
		$petmark_blogcolclass = 9;
		Petmark_Class::petmark_post_thumbnail_size('petmark-category-thumb');
		break;
	default:
		$petmark_blogclass = 'blog-nosidebar';
		$petmark_blogcolclass = 12;
		$petmark_blogsidebar = 'none';
		Petmark_Class::petmark_post_thumbnail_size('petmark-category-thumb');
}
?>

<div class="main-container">
	<div class="page-content">
		<div class="breadcrumbs-wrapper">
			<div class="container">
				<div class="breadcrumbs-inner">
					<?php Petmark_Class::petmark_breadcrumb(); ?> 
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">

				<?php if($petmark_blogsidebar=='left') : ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>

				<div class="col-xs-12 <?php echo 'col-md-'.$petmark_blogcolclass; ?>">
				
					<div class="blog-page blogs <?php echo esc_attr($petmark_blogclass); if($petmark_blogsidebar=='left') {echo ' left-sidebar'; } if($petmark_blogsidebar=='right') {echo ' right-sidebar'; } ?>">
						<?php if ( have_posts() ) : ?>

							<?php /* Start the Loop */ ?>
							<?php while ( have_posts() ) : the_post(); ?>
								
								<?php get_template_part( 'content', get_post_format() ); ?>
								
							<?php endwhile; ?>

							<?php Petmark_Class::petmark_pagination(); ?>
							
						<?php else : ?>

							<article id="post-0" class="post no-results not-found">

							<?php if ( current_user_can( 'edit_posts' ) ) :
								// Show a different message to a logged-in user who can add posts.
							?>
								<header class="entry-header">
									<h1 class="entry-title"><?php esc_html_e( 'No posts to display', 'petmark' ); ?></h1>
								</header>

								<div class="entry-content">
									<p><?php printf( wp_kses(__( 'Ready to publish your first post? <a href="%s">Get started here</a>.', 'petmark' ), array('a'=>array('href'=>array()))), admin_url( 'post-new.php' ) ); ?></p>
								</div><!-- .entry-content -->

							<?php else :
								// Show the default message to everyone else.
							?>
								<header class="entry-header">
									<h1 class="entry-title"><?php esc_html_e( 'Nothing Found', 'petmark' ); ?></h1>
								</header>

								<div class="entry-content">
									<p><?php esc_html_e( 'Apologies, but no results were found. Perhaps searching will help find a related post.', 'petmark' ); ?></p>
									<?php get_search_form(); ?>
								</div><!-- .entry-content -->
							<?php endif; // end current_user_can() check ?>

							</article><!-- #post-0 -->

						<?php endif; // end have_posts() check ?>
					</div>
					
				</div>

				<?php if( $petmark_blogsidebar=='right') : ?>
					<?php get_sidebar(); ?>
				<?php endif; ?>
				
			</div>
		</div>
	</div>
	<!-- brand logo -->
	<?php 
		if(isset($petmark_opt['inner_brand']) && function_exists('petmark_brands_shortcode') && shortcode_exists( 'ourbrands' ) ){
			if($petmark_opt['inner_brand'] && isset($petmark_opt['brand_logos'][0]) && $petmark_opt['brand_logos'][0]['thumb']!=null) { ?>
				<div class="inner-brands">
					<div class="container">
						<?php if(isset($petmark_opt['inner_brand_title']) && $petmark_opt['inner_brand_title']!=''){ ?>
							<div class="title">
								<h3><?php echo esc_html( $petmark_opt['inner_brand_title'] ); ?></h3>
							</div>
						<?php } ?>
						<?php echo do_shortcode('[ourbrands]'); ?>
					</div>
				</div>
				
			<?php }
		}
	?>
	<!-- end brand logo --> 
</div>
<?php get_footer(); ?>